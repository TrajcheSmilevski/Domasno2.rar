package Domasno2;

public class Covek {
	private String ime;
	private String prezime;
	
	public Covek(String ime,String prezime)
	{
		this.ime=ime;
		this.prezime=prezime;
	}
	
	public String getime()
	{
		return ime;
	}
	public String getprezime()
	{
		return prezime;
	}
	public void setime(String ime)
	{
		this.ime=ime;
	}
	public void setprezime(String prezime)
	{
		this.prezime=prezime;
	}
	public String toString()
	{
		String	s=("Studentot:"+ime+" "+prezime);
		return s;
	}
}