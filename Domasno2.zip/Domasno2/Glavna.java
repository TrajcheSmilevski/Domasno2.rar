
package Domasno2;
import java.util.Scanner;
public class Glavna {
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		String ime1,prezime1,fakultet1;
		String predmet1,datum1;
		Ocenka o[]=new Ocenka[100];
		int ocenka1;
		int n;
		System.out.println("Vnesete ime na studentot: ");
		ime1=sc.next();
		System.out.println("Vnesete prezime na studentot: ");
		prezime1=sc.next();
		Covek c=new Covek(ime1,prezime1);
		System.out.println("Vnesete fakultet na studentot: ");
		fakultet1=sc.next();
		System.out.println("Vnesete broj na ocenki: ");
		n=sc.nextInt();
		Student s = new Student(ime1,prezime1,fakultet1,n,o);
		s.setime(ime1);
		s.setprezime(prezime1);
		s.setfakultet(fakultet1);
		s.setocenka(o);
		System.out.println("--------------------------------------");
		System.out.println(c);
		System.out.println(s);
		for(int i=0;i<n;i++)
		{
			System.out.println(o[i]);
		}
		System.out.println("Prosekot na ovoj student e: "+s.getprosek(o));
	}
}