
package Domasno2;

public class Ocenka {
	public String predmet;
	public String datum;
	public int ocenka;
	
	public Ocenka()
	{
		predmet=" ";
		datum=" ";
		ocenka=0;
	}
	public String getpredmet()
	{
		return predmet;
	}
	public String getdatum()
	{
		return datum;
	}
	public int getocenka()
	{
		return ocenka;
	}
	public void setpredmet(String predmet)
	{
		this.predmet=predmet;
	}
	public void setdatum(String datum)
	{
		this.datum=datum;
	}
	public void setocenka(int ocenka)
	{
		this.ocenka=ocenka;
	}
	public String toString()
	{
		String s=("Predmetot e:"+predmet+", datumot na polaganje:"+datum+", ocenka:"+ocenka);
		return s;
	}
}