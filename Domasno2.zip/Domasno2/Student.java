package Domasno2;
import java.util.Scanner;
public class Student extends Covek{
	private String fakultet;
	private int n;
	private Ocenka o[]=new Ocenka[n];
	public Student(String ime,String prezime,String fakultet,int n,Ocenka o[])
	{
		super(ime,prezime);
		this.fakultet=fakultet;
		this.n=n;
		this.o=o;
	}
	
	public String getfakultet()
	{
		return fakultet;
	}
	public void setfakultet(String fakultet)
	{
		this.fakultet=fakultet;
	}
	public int getn()
	{
		return n;
	}
	public void setn(int n)
	{
		this.n=n;
	}
	public void setocenka(Ocenka o[])
	{
		Scanner sc=new Scanner(System.in);
		String predmet1,datum1;
		int ocenka1;
		for(int j=0;j<n;j++)
		{
			Ocenka o1=new Ocenka();
			System.out.println("Vnesi predmet: ");
			predmet1=sc.next();
			o1.setpredmet(predmet1);
			System.out.println("Vnesi datum: ");
			datum1=sc.next();
			o1.setdatum(datum1);
			do
			{
				System.out.println("Vnesi ocenka(5-10): ");
				ocenka1=sc.nextInt();
			}while(ocenka1<5 || ocenka1>10);
			o1.setocenka(ocenka1);	
			o[j]=o1;
		}
	}
	public double getprosek(Ocenka o[])
	{
		double prosek=0;
			for(int i=0;i<n;i++)
			{
				prosek=prosek+o[i].getocenka();
			}
			prosek=prosek/n;
			return prosek;
	}
	public String toString()
	{
		String s=("Fakultet:"+fakultet+" so broj na predmeti:"+n+" gi ima slednite ocenki:");
		return s;
	}
}